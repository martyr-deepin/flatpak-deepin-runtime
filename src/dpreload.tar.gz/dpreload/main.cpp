#include "widget.h"
#include <QDebug>
#include <QProcessEnvironment>
#include <QFontDatabase>
#include <DApplication>
#include <QSettings>
#include <QDirIterator>
#include <QFileInfo>
#include <DMainWindow>
#include <QTimer>

#include <QAudioEncoderSettings>
#include <QAudioProbe>
#include <QAudioRecorder>

DWIDGET_USE_NAMESPACE

static void preloadDir(){
    // add preload path
    QStringList paths;
    paths << "/usr/lib/gstreamer-1.0"
          << "/usr/lib/plugins";

    for (auto path : paths) {
        QDirIterator it(path, QDirIterator::Subdirectories | QDirIterator::FollowSymlinks);
        while (it.hasNext()) {
            auto filepath = it.next();
            QFileInfo fi(filepath);

            if (fi.isFile()) {
                QFile f(filepath);
                f.open(QIODevice::ReadOnly);
                f.readAll();
                f.close();
                qDebug() << "preload" << filepath;
            }
        }
    }
}

static void preloadMediaLib(QObject *obj)
{
    auto audioRecorder = new QAudioRecorder(obj);
    qDebug() << "support codecs:" << audioRecorder->supportedAudioCodecs();
    qDebug() << "support containers:" << audioRecorder->supportedContainers();

    QAudioEncoderSettings audioSettings;
    audioSettings.setQuality(QMultimedia::HighQuality);

#if QT_VERSION >= QT_VERSION_CHECK(5, 9, 0)
    audioRecorder->setAudioSettings(audioSettings);
    audioRecorder->setContainerFormat("audio/x-wav");
#else
    audioSettings.setCodec("audio/PCM");
    audioRecorder->setAudioSettings(audioSettings);
    audioRecorder->setContainerFormat("wav");
#endif
}

int main(int argc, char *argv[])
{
    Dtk::Widget::DApplication::loadDXcbPlugin();

    Dtk::Widget::DApplication app(argc, argv);
    app.setTheme("light");


    Dtk::Widget::DMainWindow dmw;
    dmw.setWindowFlags(Qt::Dialog);
    dmw.setTranslucentBackground(true);
    dmw.setFixedSize(1, 1);
    dmw.move(0, 0);
    dmw.show();

    preloadMediaLib(&dmw);
    preloadDir();

    QTimer::singleShot(5000, [ = ]() {
        qApp->quit();
    });

    return app.exec();
}
